package org.ravenest.octify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.Switch;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {

    FloatingActionButton submit;

    NumberPicker year_picker;
    NumberPicker month_picker;
    NumberPicker day_picker;

    NumberPicker hour_picker;
    NumberPicker minute_picker;
    NumberPicker second_picker;

    Switch date_switch;
    Switch time_switch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);

        setContentView(R.layout.activity_add);
        Toolbar toolbar = findViewById(R.id.toolbar_aa);

        // ToolBarをActionBarとして設定
        setSupportActionBar(toolbar);

        // ActionBarの設定
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // コントロールの取得
        submit = findViewById(R.id.submit_button);

        year_picker   = findViewById(R.id.year_picker);
        month_picker  = findViewById(R.id.month_picker);
        day_picker    = findViewById(R.id.day_picker);

        hour_picker   = findViewById(R.id.hour_picker);
        minute_picker = findViewById(R.id.minute_picker);
        second_picker = findViewById(R.id.second_picker);

        year_picker.setMinValue(year);
        year_picker.setMaxValue(year+10);

        month_picker.setMinValue(1);
        month_picker.setMaxValue(12);

        day_picker.setMinValue(1);
        day_picker.setMaxValue(31);

        hour_picker.setMinValue(0);
        hour_picker.setMaxValue(23);

        minute_picker.setMinValue(0);
        minute_picker.setMaxValue(59);

        second_picker.setMinValue(0);
        second_picker.setMaxValue(59);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}